# rfp-ibp-fitgap

Maps every demand in an uploaded RFP to SAP IBP (Integrated Business Planning) standard capabilities, assigns each demand to the correct IBP license tier (Foundation, Advanced Demand, Advanced Supply, Advanced Inventory Optimization), and generates a formatted Excel fit-gap report with extension/integration assessment.

## What you get

- **Automated demand extraction** — Reads PDF/DOCX RFPs in English or Hebrew, extracts and categorizes all functional and technical demands by IBP planning area
- **SAP IBP capability mapping** — Maps each demand to the specific IBP standard capability via live web search against SAP Help documentation
- **4-tier license model mapping** — Assigns each demand to the correct IBP license (Foundation, Advanced Demand, Advanced Supply, Advanced Inventory Optimization, or BTP/Datasphere)
- **Formatted Excel report** — Three-sheet Excel file with color-coded coverage status, license tier indicators, and extension specifications
- **Gap analysis** — Identifies demands requiring extensions or custom integrations, with technical approach recommendations

## Installation

**Multi-file skill (`skill.md` + sibling files):**
1. Download the `.zip` from the Hub
2. Unzip it anywhere on your machine — you'll get a folder named after the skill
3. Open Joule Desktop and go to **Extensions**
4. Click the dropdown next to **+ New**, then **Create Skill → Import**
5. Navigate to the unzipped **skill folder** (the one containing `skill.md`) and click **Open** — Joule Desktop imports `skill.md` together with all siblings and the `scripts/` subfolder automatically

## Prerequisites

- **Python package** (`openpyxl`) — used by the Excel generation script; installed automatically on first run
- **Sibling files:**
  - `scripts/generate_excel.py` — Excel report generator with coverage and license color coding

## Usage

Just ask Joule:

- "Analyze this RFP for IBP"
- "Check RFP against SAP IBP"
- "Map requirements to IBP capabilities"
- "IBP fit-gap analysis"

Upload a PDF or DOCX RFP file, provide the customer name, and the skill handles the rest — extraction, mapping, license assignment, and Excel generation.