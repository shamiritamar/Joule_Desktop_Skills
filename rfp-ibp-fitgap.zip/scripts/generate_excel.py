#!/usr/bin/env python3
"""
generate_excel.py  v1.1
Generates ONE Excel file from mapping_data.json:
  Sheet 1: IBP Fit-Gap Analysis (all demands with coverage + license)
  Sheet 2: Summary by Planning Area (coverage stats per planning area)
  Sheet 3: License Requirements (demand distribution by IBP license tier)

Usage:
  python3 generate_excel.py --data <json> --output <output.xlsx>
"""
import argparse, json, sys, os
from collections import defaultdict

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
except ImportError:
    print("ERROR: openpyxl not installed. Run: pip3 install openpyxl")
    sys.exit(1)

# -- Palette ----------------------------------------------------------------
SAP_BLUE = "0070AD"; SAP_DARK = "003D6B"; SAP_NAVY = "00244D"
WHITE = "FFFFFF"; LIGHT = "E8F4FD"; ALT = "F2F8FC"

COV_FILL = {
    "Standard Config":    "C6EFCE",
    "Config + Effort":    "E2EFDA",
    "Extension":          "FFEB9C",
    "Custom Integration": "FFC7CE",
}
COV_FONT = {
    "Standard Config":    "375623",
    "Config + Effort":    "375623",
    "Extension":          "7D6608",
    "Custom Integration": "9C0006",
}

LIC_FILL = {
    "Foundation":       "D6E4F0",
    "Adv Demand":       "C6EFCE",
    "Adv Supply":       "E2D0F0",
    "Adv Inventory":    "FDE9D0",
    "BTP / Datasphere": "D0E8E8",
    "Foundation + BTP": "E0E0E0",
}
LIC_FONT = {
    "Foundation":       "003D6B",
    "Adv Demand":       "375623",
    "Adv Supply":       "4A1A7A",
    "Adv Inventory":    "7D4A08",
    "BTP / Datasphere": "005050",
    "Foundation + BTP": "404040",
}

MOD_COLORS = {
    "Sales & Operations Planning":   "0070AD",
    "Demand Planning":               "00703C",
    "Demand Sensing":                "2E86C1",
    "Supply Planning":               "7030A0",
    "Inventory Optimization":        "E36C09",
    "Response & Supply Planning":    "C00000",
    "Integration & Data Management": "008080",
    "Analytics & Reporting":         "4472C4",
    "Technical / Administration":    "404040",
}
DEFAULT_MOD_COLOR = "404040"

thin = Side(style="thin", color="CCCCCC")
BDR  = Border(left=thin, right=thin, top=thin, bottom=thin)

# -- Style helpers -----------------------------------------------------------
def hdr_font():    return Font(bold=True, color=WHITE, size=10, name="Calibri")
def hdr_align():   return Alignment(horizontal="center", vertical="center", wrap_text=True)
def wrap_top():    return Alignment(wrap_text=True, vertical="top", horizontal="left")
def wrap_center(): return Alignment(wrap_text=True, vertical="center", horizontal="center")
def row_font(bold=False): return Font(bold=bold, size=10, name="Calibri")

def add_title(ws, text, subtitle, ncols):
    ws.merge_cells(f"A1:{get_column_letter(ncols)}1")
    c = ws["A1"]
    c.value = text
    c.font  = Font(bold=True, size=14, color=SAP_DARK, name="Calibri")
    c.fill  = PatternFill("solid", fgColor=LIGHT)
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 36
    ws.merge_cells(f"A2:{get_column_letter(ncols)}2")
    c2 = ws["A2"]
    c2.value = subtitle
    c2.font  = Font(italic=True, size=10, color="555555", name="Calibri")
    c2.alignment = Alignment(horizontal="center")
    ws.row_dimensions[2].height = 16

def add_header_row(ws, row_num, headers, split_at=None):
    for i, h in enumerate(headers, 1):
        c = ws.cell(row=row_num, column=i, value=h)
        c.font = hdr_font()
        bg = SAP_NAVY if (split_at and i > split_at) else SAP_BLUE
        c.fill = PatternFill("solid", fgColor=bg)
        c.alignment = hdr_align()
        c.border = BDR
    ws.row_dimensions[row_num].height = 32

def add_section_banner(ws, row_num, mod_name, ncols, color):
    ws.merge_cells(f"A{row_num}:{get_column_letter(ncols)}{row_num}")
    c = ws.cell(row=row_num, column=1, value=f"  \u25b6  {mod_name.upper()}")
    c.font  = Font(bold=True, size=11, color=WHITE, name="Calibri")
    c.fill  = PatternFill("solid", fgColor=color)
    c.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[row_num].height = 24

def set_col_widths(ws, widths):
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

# -- Sheet 1: IBP Fit-Gap Analysis ------------------------------------------
def build_fitgap_sheet(wb, demands, mappings_list, customer, has_he):
    map_lkp = {m["id"]: m for m in mappings_list}

    headers = ["ID", "IBP Module", "Sub-Area", "Customer Demand (English)"]
    widths  = [10, 24, 22, 56]
    if has_he:
        headers.append("\u05ea\u05d9\u05d0\u05d5\u05e8 \u05d4\u05d3\u05e8\u05d9\u05e9\u05d4 (\u05e2\u05d1\u05e8\u05d9\u05ea)")
        widths.append(50)
    headers.append("Notes")
    widths.append(26)
    # Add Required License column before coverage section
    headers.append("Required\nLicense")
    widths.append(18)
    base_count = len(headers)

    cov_headers = [
        "IBP Capability", "App /\nFunction", "IBP Help Link",
        "Coverage\nStatus", "Explanation", "Extension Summary", "Extension Specification"
    ]
    cov_widths = [38, 22, 48, 16, 58, 48, 64]
    headers += cov_headers
    widths  += cov_widths
    ncols = len(headers)

    cov_counts = defaultdict(int)
    for m in mappings_list:
        cov_counts[m.get("coverage", "")] += 1
    total = len(demands)
    weighted = round(
        (cov_counts["Standard Config"] * 1.0 +
         cov_counts["Config + Effort"] * 0.75 +
         cov_counts["Extension"] * 0.5 +
         cov_counts["Custom Integration"] * 0.0) / total * 100, 1
    ) if total else 0

    ws = wb.active
    ws.title = "IBP Fit-Gap Analysis"
    add_title(
        ws,
        f"{customer} \u2013 SAP IBP Fit-Gap Analysis",
        f"{total} demands  \u00b7  "
        f"Std Config: {cov_counts['Standard Config']}  \u00b7  "
        f"Config+Effort: {cov_counts['Config + Effort']}  \u00b7  "
        f"Extension: {cov_counts['Extension']}  \u00b7  "
        f"Custom Integ: {cov_counts['Custom Integration']}  \u00b7  "
        f"Weighted: {weighted}%",
        ncols,
    )
    add_header_row(ws, 3, headers, split_at=base_count)
    set_col_widths(ws, widths)
    ws.freeze_panes = "A4"

    r = 4
    cur_mod = None
    for d in demands:
        mod_name = d.get("module_name", d.get("module_code", ""))
        did      = d.get("id", "")
        m        = map_lkp.get(did, {})
        cov      = m.get("coverage", "")
        lic      = m.get("required_license", d.get("required_license", ""))

        if mod_name != cur_mod:
            cur_mod = mod_name
            add_section_banner(ws, r, mod_name, ncols,
                               MOD_COLORS.get(mod_name, DEFAULT_MOD_COLOR))
            r += 1

        row_f = (PatternFill("solid", fgColor=ALT) if r % 2 == 0
                 else PatternFill(fill_type=None))

        base_vals = [
            did,
            d.get("module_code", ""),
            d.get("sub_module", ""),
            d.get("demand_en", ""),
        ]
        if has_he:
            base_vals.append(d.get("demand_he", ""))
        base_vals.append(d.get("notes", ""))

        for ci, v in enumerate(base_vals, 1):
            c = ws.cell(row=r, column=ci, value=v)
            c.font = row_font(bold=(ci == 1))
            c.fill = row_f
            c.alignment = wrap_top()
            c.border = BDR

        # Required License (color-coded)
        lic_col = len(base_vals) + 1
        c = ws.cell(row=r, column=lic_col, value=lic)
        if lic in LIC_FILL:
            c.font = Font(bold=True, color=LIC_FONT.get(lic, "000000"),
                          size=10, name="Calibri")
            c.fill = PatternFill("solid", fgColor=LIC_FILL[lic])
        else:
            c.font = row_font(); c.fill = row_f
        c.alignment = wrap_center(); c.border = BDR

        col = base_count + 1

        # IBP Capability
        c = ws.cell(row=r, column=col, value=m.get("ibp_capability", ""))
        c.font = row_font(bold=True)
        c.fill = row_f; c.alignment = wrap_top(); c.border = BDR
        col += 1

        # App / Function
        c = ws.cell(row=r, column=col, value=m.get("ibp_app_function", ""))
        c.font = Font(size=10, name="Calibri")
        c.fill = row_f; c.alignment = wrap_top(); c.border = BDR
        col += 1

        # IBP Help Link (clickable)
        link = (m.get("ibp_help_link", "") or "").strip()
        c = ws.cell(row=r, column=col)
        if link and link.startswith("http"):
            c.value = link; c.hyperlink = link
            c.font = Font(color=SAP_BLUE, underline="single", size=9,
                          name="Calibri")
        else:
            c.value = "\u2014"; c.font = row_font()
        c.fill = row_f; c.alignment = wrap_top(); c.border = BDR
        col += 1

        # Coverage Status (color-coded)
        c = ws.cell(row=r, column=col, value=cov)
        if cov in COV_FILL:
            c.font = Font(bold=True, color=COV_FONT.get(cov, "000000"),
                          size=10, name="Calibri")
            c.fill = PatternFill("solid", fgColor=COV_FILL[cov])
        else:
            c.font = row_font(); c.fill = row_f
        c.alignment = wrap_center(); c.border = BDR
        col += 1

        # Explanation
        c = ws.cell(row=r, column=col, value=m.get("explanation", ""))
        c.font = row_font(); c.fill = row_f
        c.alignment = wrap_top(); c.border = BDR
        col += 1

        # Extension Summary
        c = ws.cell(row=r, column=col, value=m.get("ext_summary", ""))
        c.font = row_font(); c.fill = row_f
        c.alignment = wrap_top(); c.border = BDR
        col += 1

        # Extension Specification
        c = ws.cell(row=r, column=col, value=m.get("ext_spec", ""))
        c.font = row_font(); c.fill = row_f
        c.alignment = wrap_top(); c.border = BDR

        ws.row_dimensions[r].height = 60
        r += 1

    print(f"  Sheet 1: IBP Fit-Gap Analysis - {total} demands")

# -- Sheet 2: Summary by Planning Area --------------------------------------
def build_summary_sheet(wb, demands, mappings_list):
    map_lkp = {m["id"]: m for m in mappings_list}

    ws = wb.create_sheet("Summary by Planning Area")
    ncols = 7
    ws.merge_cells(f"A1:{get_column_letter(ncols)}1")
    ws["A1"].value = "Summary by Planning Area \u2014 SAP IBP Coverage"
    ws["A1"].font  = Font(bold=True, size=13, color=SAP_DARK, name="Calibri")
    ws["A1"].fill  = PatternFill("solid", fgColor=LIGHT)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    headers = ["Planning Area", "Sub-Area", "Total",
               "Std Config", "Config+Effort", "Extension", "Custom Integ."]
    add_header_row(ws, 2, headers)
    set_col_widths(ws, [28, 28, 8, 12, 14, 12, 14])
    ws.freeze_panes = "A3"

    grp = defaultdict(lambda: defaultdict(int))
    for d in demands:
        mod = d.get("module_name", d.get("module_code", ""))
        sub = d.get("sub_module", "")
        cov = map_lkp.get(d["id"], {}).get("coverage", "")
        grp[(mod, sub)]["Total"] += 1
        if cov:
            grp[(mod, sub)][cov] += 1

    r = 3
    for (mod, sub), info in sorted(grp.items()):
        row_f = (PatternFill("solid", fgColor=ALT) if r % 2 == 0
                 else PatternFill(fill_type=None))
        vals = [
            mod, sub, info["Total"],
            info.get("Standard Config", 0),
            info.get("Config + Effort", 0),
            info.get("Extension", 0),
            info.get("Custom Integration", 0),
        ]
        for ci, v in enumerate(vals, 1):
            c = ws.cell(row=r, column=ci, value=v)
            c.font = row_font()
            c.fill = row_f
            c.alignment = Alignment(
                wrap_text=True, vertical="top",
                horizontal="center" if ci > 2 else "left")
            c.border = BDR
        ws.row_dimensions[r].height = 18
        r += 1

    # Totals row
    totals = defaultdict(int)
    for info in grp.values():
        for k, v in info.items():
            totals[k] += v
    total_vals = [
        "TOTAL", "", totals["Total"],
        totals.get("Standard Config", 0),
        totals.get("Config + Effort", 0),
        totals.get("Extension", 0),
        totals.get("Custom Integration", 0),
    ]
    for ci, v in enumerate(total_vals, 1):
        c = ws.cell(row=r, column=ci, value=v)
        c.font = Font(bold=True, size=11, name="Calibri")
        c.fill = PatternFill("solid", fgColor="D9E1F2")
        c.alignment = Alignment(
            horizontal="center" if ci > 2 else "left",
            vertical="center")
        c.border = BDR

    print("  Sheet 2: Summary by Planning Area")

# -- Sheet 3: License Requirements ------------------------------------------
def build_license_sheet(wb, demands, mappings_list):
    map_lkp = {m["id"]: m for m in mappings_list}

    ws = wb.create_sheet("License Requirements")
    ncols = 7
    ws.merge_cells(f"A1:{get_column_letter(ncols)}1")
    ws["A1"].value = "SAP IBP License Requirements \u2014 Demand Distribution by License Tier"
    ws["A1"].font  = Font(bold=True, size=13, color=SAP_DARK, name="Calibri")
    ws["A1"].fill  = PatternFill("solid", fgColor=LIGHT)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 28

    headers = ["License Tier", "Total Demands", "Std Config", "Config+Effort",
               "Extension", "Custom Integ.", "Key Capabilities"]
    add_header_row(ws, 2, headers)
    set_col_widths(ws, [22, 14, 12, 14, 12, 14, 70])
    ws.freeze_panes = "A3"

    lic_desc = {
        "Foundation":       "S&OP cycle, approvals, basic forecasting, basic supply heuristic, analytics, dashboards, alerts, platform",
        "Adv Demand":       "Full ~20 forecast algorithms, demand sensing (ML), consensus planning, AI explainability, lifecycle planning",
        "Adv Supply":       "Constrained planning (finite heuristic), MILP optimizer, allocations, deployment, order scheduling",
        "Adv Inventory":    "Multi-stage safety stock optimization, service level, working capital optimization, what-if analysis",
        "BTP / Datasphere": "Non-SAP ERP integration, external data ingestion, data governance, MDM, MLOps (SAP AI Core)",
        "Foundation + BTP": "Financial planning integration (SAC), adoption telemetry, custom Fiori apps",
    }
    lic_order = ["Foundation", "Adv Demand", "Adv Supply", "Adv Inventory",
                 "BTP / Datasphere", "Foundation + BTP"]

    # Compute per-license stats
    lic_stats = defaultdict(lambda: defaultdict(int))
    for d in demands:
        lic = d.get("required_license", "")
        m = map_lkp.get(d["id"], {})
        lic_from_map = m.get("required_license", lic)
        cov = m.get("coverage", "")
        lic_stats[lic_from_map]["Total"] += 1
        if cov:
            lic_stats[lic_from_map][cov] += 1

    r = 3
    for lic in lic_order:
        info = lic_stats.get(lic, {})
        if not info:
            continue
        row_f = (PatternFill("solid", fgColor=ALT) if r % 2 == 0
                 else PatternFill(fill_type=None))
        vals = [
            lic,
            info.get("Total", 0),
            info.get("Standard Config", 0),
            info.get("Config + Effort", 0),
            info.get("Extension", 0),
            info.get("Custom Integration", 0),
            lic_desc.get(lic, ""),
        ]
        for ci, v in enumerate(vals, 1):
            c = ws.cell(row=r, column=ci, value=v)
            if ci == 1 and lic in LIC_FILL:
                c.font = Font(bold=True, color=LIC_FONT.get(lic, "000000"),
                              size=10, name="Calibri")
                c.fill = PatternFill("solid", fgColor=LIC_FILL[lic])
            else:
                c.font = row_font(bold=(ci == 1))
                c.fill = row_f
            c.alignment = Alignment(
                wrap_text=True, vertical="top",
                horizontal="center" if 1 < ci < 7 else "left")
            c.border = BDR
        ws.row_dimensions[r].height = 28
        r += 1

    # Totals row
    grand_total = sum(info.get("Total", 0) for info in lic_stats.values())
    grand_sc = sum(info.get("Standard Config", 0) for info in lic_stats.values())
    grand_ce = sum(info.get("Config + Effort", 0) for info in lic_stats.values())
    grand_ex = sum(info.get("Extension", 0) for info in lic_stats.values())
    grand_ci = sum(info.get("Custom Integration", 0) for info in lic_stats.values())
    total_vals = ["TOTAL", grand_total, grand_sc, grand_ce, grand_ex, grand_ci, ""]
    for ci, v in enumerate(total_vals, 1):
        c = ws.cell(row=r, column=ci, value=v)
        c.font = Font(bold=True, size=11, name="Calibri")
        c.fill = PatternFill("solid", fgColor="D9E1F2")
        c.alignment = Alignment(
            horizontal="center" if 1 < ci < 7 else "left",
            vertical="center")
        c.border = BDR

    # License model note
    r += 2
    ws.merge_cells(f"A{r}:{get_column_letter(ncols)}{r}")
    c = ws.cell(row=r, column=1,
                value="Note: SAP IBP Foundation is the mandatory base license. "
                      "Advanced Demand, Advanced Supply, and Advanced Inventory Optimization "
                      "are optional add-on licenses. BTP / Datasphere components are licensed separately.")
    c.font = Font(italic=True, size=9, color="555555", name="Calibri")
    c.alignment = Alignment(wrap_text=True)

    print("  Sheet 3: License Requirements")

# -- Main -------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(
        description="RFP IBP Fit-Gap Excel Generator v1.1")
    p.add_argument("--data",   required=True,
                   help="Path to mapping_data.json")
    p.add_argument("--output", required=True,
                   help="Output .xlsx file path")
    args = p.parse_args()

    if not os.path.isfile(args.data):
        print(f"ERROR: {args.data} not found")
        sys.exit(1)

    with open(args.data, "r", encoding="utf-8") as f:
        data = json.load(f)

    demands     = data.get("demands", [])
    mappings    = data.get("mappings", [])
    customer    = data.get("customer", "Customer")
    source_lang = data.get("source_lang", "en")
    has_he      = (source_lang == "he"
                   or any(d.get("demand_he", "").strip() for d in demands))

    wb = openpyxl.Workbook()
    build_fitgap_sheet(wb, demands, mappings, customer, has_he)
    build_summary_sheet(wb, demands, mappings)
    build_license_sheet(wb, demands, mappings)
    wb.save(args.output)

    total = len(demands)
    cov_counts = defaultdict(int)
    lic_counts = defaultdict(int)
    for m in mappings:
        cov_counts[m.get("coverage", "")] += 1
        lic_counts[m.get("required_license", "")] += 1
    weighted = round(
        (cov_counts["Standard Config"] * 1.0 +
         cov_counts["Config + Effort"] * 0.75 +
         cov_counts["Extension"] * 0.5) / total * 100, 1
    ) if total else 0

    print(f"\nFile saved: {args.output}")
    print(f"  {total} demands | Weighted coverage: {weighted}%")
    print(f"  Std Config: {cov_counts['Standard Config']}"
          f" | Config+Effort: {cov_counts['Config + Effort']}"
          f" | Extension: {cov_counts['Extension']}"
          f" | Custom Integ: {cov_counts['Custom Integration']}")
    print(f"  License distribution:")
    for lic in ["Foundation", "Adv Demand", "Adv Supply", "Adv Inventory",
                "BTP / Datasphere", "Foundation + BTP"]:
        if lic_counts.get(lic, 0) > 0:
            print(f"    {lic}: {lic_counts[lic]} demands")

if __name__ == "__main__":
    main()